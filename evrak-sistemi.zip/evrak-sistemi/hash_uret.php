<?php
$sifre = "admin123"; // İstediğin şifreyi buraya yaz
$hash = password_hash($sifre, PASSWORD_DEFAULT);
echo "Şifrenin hash hali: " . $hash;
?>
