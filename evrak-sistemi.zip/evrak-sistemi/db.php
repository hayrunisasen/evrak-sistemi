<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "evrak_sistemi";

// MySQL bağlantısı
$conn = new mysqli($host, $user, $pass, $db);

// Bağlantı kontrolü
if ($conn->connect_error) {
  die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}
?>
