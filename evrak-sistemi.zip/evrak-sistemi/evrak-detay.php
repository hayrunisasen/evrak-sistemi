<?php
include "db.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Geçersiz evrak ID");
}

$id = (int)$_GET['id'];

$sql = "SELECT * FROM evraklar WHERE id = $id LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Evrak bulunamadı.");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Evrak Detayı | Ardahan Üniversitesi</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="header">
    <img src="images/ardahan_logo.png" alt="Ardahan Üniversitesi Logosu" class="logo" />
    <h1>Ardahan Üniversitesi Evrak Takip Sistemi</h1>
  </div>

  <div class="container">
    <h2>Evrak Detayları</h2>

    <p><strong>ID:</strong> <?php echo $row['id']; ?></p>
    <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($row['ad']); ?></p>
    <p><strong>Belge Türü:</strong> <?php echo htmlspecialchars($row['belge_turu']); ?></p>
    <p><strong>Açıklama:</strong> <?php echo nl2br(htmlspecialchars($row['aciklama'])); ?></p>
    <p><strong>Tarih:</strong> <?php echo $row['tarih']; ?></p>

    <?php if (!empty($row['qr_kod']) && file_exists($row['qr_kod'])): ?>
      <p><strong>QR Kodu:</strong></p>
      <img src="<?php echo $row['qr_kod']; ?>" alt="QR Kod" />
    <?php else: ?>
      <p>QR kod bulunamadı.</p>
    <?php endif; ?>

    <p><a href="evrak-liste.php" class="btn">Geri Dön</a></p>
  </div>
</body>
</html>

<?php $conn->close(); ?>
