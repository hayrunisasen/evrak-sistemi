<?php
include "db.php";

$search = "";
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
}

// Basit arama sorgusu: ad veya belge_turu içinde arama
$sql = "SELECT * FROM evraklar WHERE ad LIKE '%$search%' OR belge_turu LIKE '%$search%' ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Evrak Listesi | Ardahan Üniversitesi</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="header">
    <img src="images/ardahan_logo.png" alt="Ardahan Üniversitesi Logosu" class="logo" />
    <h1>Ardahan Üniversitesi Evrak Takip Sistemi</h1>
  </div>

  <div class="container">
    <h2>Evrak Listesi</h2>

    <form method="GET" action="evrak-liste.php" class="search-form">
      <input type="text" name="search" placeholder="Ad veya Belge Türü ara..." value="<?php echo htmlspecialchars($search); ?>" />
      <input type="submit" value="Ara" />
      <a href="evrak-ekle.php" class="btn btn-secondary" style="margin-left:10px;">Yeni Evrak Ekle</a>
    </form>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Ad Soyad</th>
          <th>Belge Türü</th>
          <th>Tarih</th>
          <th>Detay</th>
        </tr>
      </thead>
      <tbody>
      <?php
      if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>".$row['id']."</td>";
              echo "<td>".htmlspecialchars($row['ad'])."</td>";
              echo "<td>".htmlspecialchars($row['belge_turu'])."</td>";
              echo "<td>".htmlspecialchars($row['tarih'])."</td>";
              echo "<td><a href='evrak-detay.php?id=".$row['id']."' class='btn btn-small'>Detay</a></td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='5' style='text-align:center;'>Kayıt bulunamadı.</td></tr>";
      }
      ?>
      </tbody>
    </table>
  </div>
</body>
</html>

<?php
$conn->close();
?>

