<?php
include "db.php";
include "phpqrcode/qrlib.php";

echo '<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Evrak Kaydetme Sonucu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="header">
    <img src="images/ardahan_logo.png" alt="Ardahan Üniversitesi Logosu" class="logo" />
    <h1>Ardahan Üniversitesi Evrak Takip Sistemi</h1>
  </div>
  <div class="container">';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad = $conn->real_escape_string($_POST['ad']);
    $belge_turu = $conn->real_escape_string($_POST['belge_turu']);
    $aciklama = $conn->real_escape_string($_POST['aciklama']);
    $tarih = $conn->real_escape_string($_POST['tarih']);

    $sql = "INSERT INTO evraklar (ad, belge_turu, aciklama, tarih) VALUES ('$ad', '$belge_turu', '$aciklama', '$tarih')";

    if ($conn->query($sql) === TRUE) {
        $last_id = $conn->insert_id;

        $qr_icerik = "http://localhost/evrak-sistemi/dogrula.php?evrak_id=" . $last_id;
        $qr_dosya = "qr/evrak_" . $last_id . ".png";

        QRcode::png($qr_icerik, $qr_dosya, QR_ECLEVEL_L, 4);

        $conn->query("UPDATE evraklar SET qr_kod='$qr_dosya' WHERE id=$last_id");

        echo '<div class="success-box">';
        echo "<h2>Evrak başarıyla kaydedildi!</h2>";
        echo "<p>Evrak No: <strong>$last_id</strong></p>";
        echo "<p><img src='$qr_dosya' alt='QR Kod'></p>";
        echo '<a href="evrak-ekle.php" class="btn">Yeni Evrak Ekle</a>';
        echo '</div>';
    } else {
        echo '<div class="error-box">';
        echo "Hata: " . $conn->error;
        echo '</div>';
    }
} else {
    echo '<div class="error-box">';
    echo "Form gönderilmedi.";
    echo '</div>';
}

$conn->close();

echo '</div></body></html>';
?>



