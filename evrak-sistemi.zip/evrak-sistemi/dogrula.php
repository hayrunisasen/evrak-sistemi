<?php
include "db.php";

if (!isset($_GET['evrak_id']) || !is_numeric($_GET['evrak_id'])) {
    die("Geçersiz veya eksik evrak numarası.");
}

$evrak_id = (int)$_GET['evrak_id'];

$sql = "SELECT * FROM evraklar WHERE id = $evrak_id LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $evrak = null;
} else {
    $evrak = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Evrak Doğrulama | Ardahan Üniversitesi</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="header">
    <img src="images/ardahan_logo.png" alt="Ardahan Üniversitesi Logosu" class="logo" />
    <h1>Ardahan Üniversitesi Evrak Takip Sistemi</h1>
  </div>

  <div class="container">
    <h2>Evrak Doğrulama Sonucu</h2>

    <?php if ($evrak): ?>
      <p><strong>Evrak No:</strong> <?php echo $evrak['id']; ?></p>
      <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($evrak['ad']); ?></p>
      <p><strong>Belge Türü:</strong> <?php echo htmlspecialchars($evrak['belge_turu']); ?></p>
      <p><strong>Açıklama:</strong> <?php echo nl2br(htmlspecialchars($evrak['aciklama'])); ?></p>
      <p><strong>Tarih:</strong> <?php echo $evrak['tarih']; ?></p>

      <?php if (!empty($evrak['qr_kod']) && file_exists($evrak['qr_kod'])): ?>
        <p><strong>QR Kodu:</strong></p>
        <img src="<?php echo $evrak['qr_kod']; ?>" alt="QR Kod" />
      <?php endif; ?>

      <p style="color:green; font-weight:bold; margin-top: 20px;">Evrak doğrulandı, kayıtlı ve geçerlidir.</p>

    <?php else: ?>
      <p style="color:red; font-weight:bold;">Evrak bulunamadı veya geçersiz.</p>
    <?php endif; ?>

    <p><a href="evrak-ekle.php" class="btn">Yeni Evrak Ekle</a> 
       <a href="evrak-liste.php" class="btn btn-secondary">Evrak Listesi</a></p>
  </div>
</body>
</html>

<?php $conn->close(); ?>


