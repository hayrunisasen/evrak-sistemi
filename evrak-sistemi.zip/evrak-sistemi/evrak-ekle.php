<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Evrak Ekle | Üniversite Evrak Takip Sistemi</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="header">
    <img src="images/ardahan_logo.png" alt="Ardahan Üniversitesi Logosu" class="logo" />
    <h1>Ardahan Üniversitesi Evrak Takip Sistemi</h1>
  </div>

  <div class="container">
    <h2>Üniversite Evrak Ekleme Formu</h2>
    <form action="evrak-kaydet.php" method="POST">
      <label>Ad Soyad:</label>
      <input type="text" name="ad" required />

      <label>Belge Türü:</label>
      <select name="belge_turu" required>
        <option value="Transkript">Transkript</option>
        <option value="Öğrenci Belgesi">Öğrenci Belgesi</option>
        <option value="Mezuniyet Belgesi">Mezuniyet Belgesi</option>
        <option value="Diğer">Diğer</option>
      </select>

      <label>Açıklama:</label>
      <textarea name="aciklama" rows="4"></textarea>

      <label>Tarih:</label>
      <input type="date" name="tarih" required />

      <input type="submit" value="Evrakı Kaydet" />
    </form>
  </div>
</body>
</html>
